

# 🍇 Sistema de Pedidos - Loja de Açaí

## Visão Geral
Sistema completo de pedidos online para loja de açaí, estilo delivery profissional, com tema roxo/lilás, mobile first, integração WhatsApp e painel administrativo.

---

## 1. 🎨 Design & Tema
- Paleta de cores em roxo/lilás com acentos brancos
- Interface mobile first, responsiva
- Tipografia moderna e limpa
- Ícones e cards com visual profissional de delivery

## 2. 🏠 Página Inicial (Home)
- Logo da loja no topo
- Nome da loja e endereço/bairro
- Badge de status "Aberto" / "Fechado" (vindo do banco de dados)
- Tempo estimado de entrega
- Botão "Pedir Agora" que leva ao cardápio
- Se loja fechada, bloquear pedidos com aviso

## 3. 📋 Cardápio
- Produtos carregados do banco de dados em tempo real
- Organizados por categorias (ex: Açaís, Cremes, Bebidas)
- Card de produto com: imagem, nome, descrição e preço
- Botão "+" para adicionar ao carrinho
- Ao adicionar, abrir modal para selecionar **adicionais** (múltipla escolha, com preço individual)
- Carrinho flutuante com contador de itens atualizado em tempo real

## 4. 🛒 Carrinho
- Lista de itens com nome, adicionais selecionados, quantidade e preço
- Botões para alterar quantidade (+/-) e remover item
- Subtotal dos produtos
- Taxa de entrega (configurável pelo admin)
- Total geral calculado automaticamente
- Botão "Finalizar Pedido"

## 5. 🧾 Checkout
- Formulário com campos obrigatórios e validação:
  - Nome completo
  - Telefone
  - Endereço de entrega
  - Ponto de referência
  - Tipo de serviço (Entrega / Retirada)
  - Forma de pagamento (Dinheiro, Pix, Cartão)
- Se dinheiro: campo "Troco para quanto?"
- Botão "Enviar Pedido"

## 6. 📲 Envio via WhatsApp
- Ao finalizar, gerar mensagem automática formatada com:
  - Itens do pedido (com adicionais e quantidades)
  - Subtotal, taxa de entrega e total
  - Dados do cliente (nome, telefone, endereço, referência)
  - Forma de pagamento
- Abrir link `wa.me/5521979917408` com a mensagem completa
- Tela de confirmação "Pedido enviado com sucesso!"

## 7. 🔐 Painel Admin (/admin)
- Tela de login com email e senha
- Usuário inicial pré-cadastrado: `garenafreefiree1981@gmail.com`
- Acesso protegido — redireciona para login se não autenticado

### Funcionalidades do Admin:
- **Produtos**: Criar, editar, excluir, alterar preço, upload de imagem
- **Categorias**: Criar, editar, excluir categorias de produtos
- **Adicionais**: Criar, editar, excluir itens adicionais com preço
- **Configurações da Loja**:
  - Abrir/fechar loja (toggle)
  - Definir taxa de entrega
  - Alterar número do WhatsApp
  - Editar nome, endereço e tempo de entrega

## 8. 🗄️ Banco de Dados (Lovable Cloud)
- **Tabelas**: products, categories, addons, store_settings
- **Auth**: Autenticação nativa do Supabase para login do admin
- **Storage**: Bucket para imagens dos produtos
- **RLS**: Leitura pública dos produtos, escrita apenas para admin autenticado

## 9. 📱 Fluxo do Cliente
`Home → Cardápio → Selecionar produtos e adicionais → Carrinho → Checkout → WhatsApp`

